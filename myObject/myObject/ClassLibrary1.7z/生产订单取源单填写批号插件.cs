﻿using System.ComponentModel;
using Kingdee.BOS.App.Data;
using Kingdee.BOS.Core.Bill.PlugIn;
using Kingdee.BOS.Core.DynamicForm.PlugIn.Args;
using Kingdee.BOS.Orm.DataEntity;

namespace Kingdee.Bos.ProJect.BillBeforeSave.Plugln
{
    [Description("生产订单取源单填写批号插件")]
    [Kingdee.BOS.Util.HotUpdate]
    public class workOrderWriteLot : AbstractBillPlugIn
    {
        public override void BarItemClick(BarItemClickEventArgs e)
        {
            base.BarItemClick(e);
            if (e.BarItemKey.Equals("tbSplitSave"))
            {
                //this.View.ShowMessage(this.View.Model.GetEntryRowCount("FTreeEntity").ToString());

                int rowNum = this.View.Model.GetEntryRowCount("FTreeEntity");
                for (int idx = 0; idx < rowNum; idx++)
                {
                    
                    if (!this.View.GetFieldEditor("FLot", idx).Enabled)
                    {
                        continue;
                    }

                    long sourceId = (long)this.View.Model.GetEntryPKValue("FTreeEntity", idx);

                    if (sourceId == 0)
                    {
                        continue;
                    }
                    
                    this.View.Model.SetValue("FLot", sourceId.ToString(), idx);

                }
            }

        }
    }

}



